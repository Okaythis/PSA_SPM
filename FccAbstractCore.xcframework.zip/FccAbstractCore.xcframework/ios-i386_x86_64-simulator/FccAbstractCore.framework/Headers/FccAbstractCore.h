//
//  FccAbstractCore.h
//  FccAbstractCore
//
//  Created by Ben Ogie on 03/06/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for FccAbstractCore.
FOUNDATION_EXPORT double FccAbstractCoreVersionNumber;

//! Project version string for FccAbstractCore.
FOUNDATION_EXPORT const unsigned char FccAbstractCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FccAbstractCore/PublicHeader.h>


