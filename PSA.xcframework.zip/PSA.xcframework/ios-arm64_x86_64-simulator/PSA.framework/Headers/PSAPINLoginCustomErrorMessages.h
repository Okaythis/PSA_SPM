//
//  PSAPINLoginCustomErrorMessages.h
//  PSA
//
//  Created by SK on 31/08/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, PSAPINLoginErrorCode) {
    serverError,
    invalidPinError,
};

@interface PSAPINLoginCustomErrorMessages : NSObject

- (void)setErrorMessage:(NSString *)message forError:(PSAPINLoginErrorCode)errorCode;
- (nullable NSString *)getErrorMessageForError:(PSAPINLoginErrorCode)errorCode;

@end

NS_ASSUME_NONNULL_END
