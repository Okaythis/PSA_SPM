// Copyright © Protectoria. All rights reserved.

#import <PSA/OperationType.h>
#import <PSA/AuthMethod.h>
#import <DefaultPsaUi/DefaultPsaUi.h>

@interface TransactionInfo : NSObject

@property OperationType operationType;
@property AuthMethod authMethod;
@property NSArray<PSAPayment *> *payments;
@property NSDictionary<NSString*, NSString*> *args;
@property NSNumber *statusCode;

@end
