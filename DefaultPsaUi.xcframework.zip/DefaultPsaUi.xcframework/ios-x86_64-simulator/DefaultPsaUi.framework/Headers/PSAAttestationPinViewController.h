//
//  PSAAttestationPinViewController.h
//  DefaultPsaUi
//
//  Created by Satheesh Kannan on 16/02/23.
//  Copyright © 2023 Protectoria. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol PSAAttestationPinDelegate <NSObject>

- (void)submittedPIN: (NSString *)pin;

@end

@interface PSAAttestationPinViewController : UIViewController

+ (instancetype)controllerWithDelegate: (id<PSAAttestationPinDelegate>)delegate;

@end

NS_ASSUME_NONNULL_END
