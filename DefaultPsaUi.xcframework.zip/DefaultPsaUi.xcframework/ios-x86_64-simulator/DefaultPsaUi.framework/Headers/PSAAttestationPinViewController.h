//
//  PSAAttestationPinViewController.h
//  DefaultPsaUi
//
//  Created by Satheesh Kannan on 16/02/23.
//  Copyright © 2023 Protectoria. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <PSACommon/PSACommon.h>

NS_ASSUME_NONNULL_BEGIN

@protocol PSAAttestationPinDelegate <NSObject>

- (void)submittedPIN: (NSString *)pin;

@end

@interface PSAAttestationPinViewController : UIViewController

+ (instancetype)controllerWithDelegate: (id<PSAAttestationPinDelegate>)delegate andTheme:(PSAAttestationPinTheme *) theme;

- (void)resetScreen;
- (void)showErrorMessage;

@end

NS_ASSUME_NONNULL_END
