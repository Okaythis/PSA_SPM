// Copyright © Protectoria. All rights reserved.

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum PSASharedStatuses{
    //Generic status codes
    SensitiveDataDecryptionError = 64,
    HasActiveSession = 60,
    NoAPNSToken = 56,
    NotEnrolled = 52,
    InternalLogicError = 48,
    InternalCommonError = 44,
    ExpiredTransaction = 40,
    TimeOutError = 30,
    NoInternetError = 20,
    Undefined = 0,
    Success = 1,
    
    //SDK Attestation Status Codes
    AttestationSuccess = 900,
    AttestationFailed = 901,
    AttestationKidNotAvailable = 902,
    AttestationDeviceNotEnrolled = 903,
    AttestationBiometricNotAvailable = 904,
    AttestationPinVerificationFailure = 905,
    AttestationBiometricVerificationFailure = 906,
    
    //SDK status codes
    PinUserForgotPin = 907,
    PinInvalidRetryArgument = 908,
    PinInvalidClientUrlArgument = 909,
    PinInvalidPubKeyArgument = 910,
    PinVerificationServerNotReachable = 911,
    PinInvalidPinLengthArgument = 912,
    PinUserCancelled = 913,
    AttestationBiometricSensorLockout = 914,
    PinInvalidUserExternalIdArgument = 920,
    
    //Server API Status Codes
    PinVerificationSuccess = 800,
    PinDecryptionError = 810,
    PinInvalidPin = 815,
    PinMaximumRetriesExceeded = 819,
    PinUserAccountLocked = 830,
    PinInvalidUser = 831,
    PinPayloadSignatureError = 832,
    PinExpiredTimestamp = 833,
    PinInvalidVersionNumber = 834
    
} PSASharedStatuses;

extern NSString * _Nonnull const StatusToString[];

NS_ASSUME_NONNULL_END
