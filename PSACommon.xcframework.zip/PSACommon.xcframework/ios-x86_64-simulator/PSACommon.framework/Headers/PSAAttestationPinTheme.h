//
//  PSAAttestationPinTheme.h
//  PSACommon
//
//  Created by Satheesh Kannan on 13/03/23.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSAAttestationPinTheme : NSObject

@property (nonatomic, strong) UIColor *screenBackgroundColor;
@property (nonatomic, strong) UIColor *screenTitleTextColor;
@property (nonatomic, strong) UIColor *screenSubtitleTextColor;
@property (nonatomic, strong) UIColor *screenSubtitleErrorTextColor;
@property (nonatomic, retain) UIColor *screenForgotPinTextColor;
@property (nonatomic, strong) UIColor *pinTextColor;
@property (nonatomic, strong) UIColor *pinButtonTextColor;
@property (nonatomic, strong) UIColor *pinButtonBackgroundColor;

@property (nonatomic, retain) NSString *screenTitleText;
@property (nonatomic, retain) NSString *screenSubtitleText;
@property (nonatomic, retain) NSString *screenSubtitleErrorText;
@property (nonatomic, retain) NSString *screenForgotPinText;
@property (nonatomic) bool shuffleKeyPad;

@end

NS_ASSUME_NONNULL_END
